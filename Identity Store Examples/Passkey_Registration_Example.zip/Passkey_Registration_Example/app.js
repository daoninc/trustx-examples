import {
    create,
    parseCreationOptionsFromJSON
} from "https://cdn.jsdelivr.net/npm/@github/webauthn-json@2.0.2/dist/esm/webauthn-json.browser-ponyfill.js";

const CREATE_ERROR = 'CREATE_ERROR';
const USER_CANCELED = 'USER_CANCELED';
const NOT_ALLOWED_ERROR = 'NotAllowedError';
const ABORT_ERROR = 'AbortError';
const CONFIGURATION_ERROR = 'CONFIGURATION_ERROR';
const CLIENT_TIMEOUT = 'CLIENT_TIMEOUT'
const CLIENT_TIMEOUT_MESSAGE = 'User session has expired.'

let passkeyRegClientRequest;

function sendRequest(passkeyRegClientResponse) {
    if (window.parent !== window) {
        window.parent.postMessage({
            event: 'SEND',
            variables: { passkeyRegClientResponse: JSON.stringify(passkeyRegClientResponse) }
        }, '*');
    } 
};

function parseError({ type, message }) {
    return {
        clientError: {
            errorType: type,
            errorMessage: message
        }
    };
};

const controller = new AbortController();

window.addEventListener('message', function (event) {
    if (event.data.variables) {
        const variables = event.data.variables;
        const constants = variables.constants;
        const sessionData = variables.sessionData;

        if (sessionData.passkeyRegClientRequest) {
            passkeyRegClientRequest = sessionData.passkeyRegClientRequest;
        }

        if (constants.timeoutInSeconds) {
            setTimeout(async () => {
                controller.abort()
            }, (constants.timeoutInSeconds - 12) * 1000)
        }
    } else {
        console.log('No variables received');
    }
});

async function registerPasskey(passkeyRegClientRequestUpdated) {
    let serverPublicKeyCredential;

    try {
        serverPublicKeyCredential = parseCreationOptionsFromJSON({
            publicKey: {
                ...passkeyRegClientRequestUpdated
            }
        })
    } catch (err) {
        return parseError({ type: CONFIGURATION_ERROR, message: err.message });
    }

    try {
        const signal = controller.signal;
        const response = await create({ ...serverPublicKeyCredential, signal });

        return response;
    } catch (err) {
        if (err.name === NOT_ALLOWED_ERROR) {
            return parseError({ type: USER_CANCELED, message: err.message });
        }

        if (err.name === ABORT_ERROR) {
            return parseError({ type: CLIENT_TIMEOUT, message: CLIENT_TIMEOUT_MESSAGE });
        }

        return parseError({ type: CREATE_ERROR, message: err.message });
    }
}

document.getElementById('registration').addEventListener('submit', async (event) => {
    event.preventDefault();

    const name = document.getElementById('name').value;
    const displayName = document.getElementById('displayName').value;

    const user = {
        ...passkeyRegClientRequest.user,
        name,
        displayName
    }

    const passkeyRegClientResponse = await registerPasskey({ ...passkeyRegClientRequest, user });

    sendRequest(passkeyRegClientResponse)
});

window.parent.postMessage({ event: 'READY' }, '*');
